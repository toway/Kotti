# See http://kotti.readthedocs.org/en/latest/developing/testing.html

pytest_plugins = "kotti"

Changelog
=========

0.1b2(2013-05-03)
-----------------

- Fixing configuration test. We just need() fanstatic lib now.
- Use util method from kotti_settings to determine if the widget should be shown.


0.1b1(2013-04-18)
-----------------

- Added settings for the tagcloud.
- Added some description to the readme.


0.1a1
-----

-   Initial release.

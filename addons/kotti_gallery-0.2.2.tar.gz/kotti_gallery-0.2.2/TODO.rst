TODO
====

-   Add support for remote galleries (e.g. flickr photosets).

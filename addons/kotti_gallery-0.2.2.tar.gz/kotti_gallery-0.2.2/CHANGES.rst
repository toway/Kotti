CHANGES
=======

0.2.2
-----

-   Pseudo-crop images with CSS to have all thumbs the same height in
    gallery views.

0.2.1
-----

-   Implement IDefaultWorkflow.

0.2
---

-   Use `Bootstrap Image Gallery`_.

-   Add several multicolumn layouts.

-   Depend on Kotti>=0.8 and its new add / edit form classes.

-   Add German translation.

0.1
---

-   Initial release.

-   Copied code from kotti_image_gallery.


.. _Bootstrap Image Gallery: http://blueimp.github.com/Bootstrap-Image-Gallery/

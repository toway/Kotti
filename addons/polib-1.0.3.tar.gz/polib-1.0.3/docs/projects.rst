.. _projects:

Projects using polib
====================

polib is used by many opensource projects, here are some of them:

* `Mercurial <http://mercurial.selenic.com>`_
* `Transifex <http://www.transifex.net/>`_
* `Launchpad ubuntu translator tools <https://translations.launchpad.net/>`_
* `Django-rosetta <http://code.google.com/p/django-rosetta/>`_
* `The evergreen library system <http://www.open-ils.org/>`_
* `Qooxdoo <http://qooxdoo.org/>`_
* `<http://www.linux.rk.edu.pl/tra/list/>`_
* `Lictionary <http://www.lictionary.in/>`_

If you are using polib and wish to be listed here (or not)
`let me know <izimobil@gmail.com>`_.
